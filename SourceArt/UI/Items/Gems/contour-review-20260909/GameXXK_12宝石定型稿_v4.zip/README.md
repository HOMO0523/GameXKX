# 宝石类型定型稿

当前审阅版本为v4：12种类型各1张固定图标，所有品质共用。用户取消了其它9档品质图，品质交给现有装备名称、道具底、tooltip Shader；镶嵌文字按每颗宝石自身品质着色。

- `gem-types-review-v4.png`：12种完整对照。
- `gem-types-48px-review-v4.png`：64px彩色、48px彩色/灰度/剪影。
- `type-icons-v4/`：12张512×512透明PNG。
- `type-icon-generation-records-v4.json`：内置imagegen提示词、来源和用户许可的统一百分号合成参数。
- `type-icon-manifest-v4.json`：源文件与最终图哈希、透明边界、共同百分号尺寸和掩码等校验。

只有攻击/防御/生命百分比三张含中心%。三者使用同一182×204像素浅浮雕符号和同一放置坐标，分别为浅红、浅蓝、浅绿。宝石本体使用同系列基础图，无双宝石，符号之外不改本体。

美术由内置imagegen生成，背景清理和统一符号合成均经用户明确允许，由`python scripts/prepare_gem_type_icon_review.py --revision v4`处理。旧版与原始生成图保留供比较。

状态：等待用户定型审阅，尚未导入UE，不能视为新增宝石玩法已实现。
